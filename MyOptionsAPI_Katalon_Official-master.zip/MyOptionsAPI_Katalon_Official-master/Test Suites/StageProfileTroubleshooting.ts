<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>StageProfileTroubleshooting</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>0</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <testSuiteGuid>8c7c77b8-0286-42cc-8f57-566d62ba20da</testSuiteGuid>
   <testCaseLink>
      <guid>97f09a5e-c59a-4869-a8bb-100dd595ca51</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/SignUp/MO001_SignUpA_ValidStudent_200ok</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>918f47b6-41cc-4c92-95c7-13c068a2f8ff</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Quiz/MO001_QuestionsA_GetQuestions_200ok</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>49eeceaf-c624-4500-98e1-9f7564e4ea20</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Quiz/MO002_QuestionsA_GetQuestionsCount_200ok</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>5ce6a0a4-e5eb-4636-a4c8-23059b73d990</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Quiz/MO003_QuestionsA_GetQuestionsbyID_200ok</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>9bec5789-9ebc-41f0-a42a-bbcaf2bac66f</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Schools/HighSchools/MO001_HighSchoolA_GetHighSchools_200ok</testCaseId>
   </testCaseLink>
</TestSuiteEntity>
