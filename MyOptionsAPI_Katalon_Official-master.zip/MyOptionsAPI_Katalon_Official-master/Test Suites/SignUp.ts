<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>SignUp</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>0</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <testSuiteGuid>ab303892-567b-4968-9684-9d2d77a589d0</testSuiteGuid>
   <testCaseLink>
      <guid>751472b8-2777-4196-a1cf-b574e4d50a2a</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/SignUp/MO001_SignUpA_ValidStudent_200ok</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>12270356-ee48-4197-9d7d-bc443c1fd283</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/SignUp/MO002_SignUpA_InvalidStudentEmail_500</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>67119afe-6535-4b15-ab7e-72679503bc09</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/SignUp/MO003_SignUpA_BlankPassswordStudent_400</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>34cf3903-0660-4dc5-8c34-534a305cf7b8</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/SignUp/MO004_SignUpA_BlankFirstNameStudent_400</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>e0f9d4d7-7e4f-4d3a-a7d4-d19476e661c9</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/SignUp/MO005_SignUpA_BlankLastNameStudent_400</testCaseId>
   </testCaseLink>
</TestSuiteEntity>
