<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>BearertokenxUserSchools</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>0</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <testSuiteGuid>d1a2eacf-b8aa-4a2b-8854-29e59cfb154e</testSuiteGuid>
   <testCaseLink>
      <guid>c7c6f3ac-8f69-42f6-97c5-a9875c8fee8f</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Login/MO001_LoginA_ValidLogin_200ok</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>d339ea79-86dd-445f-b861-2bbeab7bab0a</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Checklist/M0001_ChecklistA_GetChecklist_200ok</testCaseId>
      <variableLink>
         <testDataLinkId></testDataLinkId>
         <type>DEFAULT</type>
         <value></value>
         <variableId>eba3c5fd-dbab-45e6-9d4e-61e0dd968fd2</variableId>
      </variableLink>
      <variableLink>
         <testDataLinkId></testDataLinkId>
         <type>DEFAULT</type>
         <value></value>
         <variableId>5e1f22bf-0b5d-4905-8deb-ea1ee605f9f5</variableId>
      </variableLink>
   </testCaseLink>
   <testCaseLink>
      <guid>ac2d4327-8c75-4100-bbd0-03c32a315af2</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Preference Survey/MO001_UserPreferenceA_ValidRequest_200ok</testCaseId>
   </testCaseLink>
</TestSuiteEntity>
