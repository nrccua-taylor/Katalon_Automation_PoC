<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>Mentor</name>
   <tag></tag>
   <integratedEntity>
      <productName>qTest</productName>
      <properties>
         <entry>
            <key>0</key>
            <value>{&quot;parent&quot;:{&quot;parentName&quot;:&quot;MO Sprint 8 20190509-20190530&quot;,&quot;name&quot;:&quot;Sprint 8 Katalon Automation API&quot;,&quot;id&quot;:1446467,&quot;type&quot;:4,&quot;parentId&quot;:354145},
&quot;default&quot;:true,&quot;name&quot;:&quot;Mentor&quot;,&quot;pid&quot;:&quot;&quot;,&quot;id&quot;:2495655,&quot;testRuns&quot;:[{&quot;name&quot;:&quot;MO001_SignUpA_ValidStudent_200ok&quot;,&quot;qTestCaseId&quot;:25378536,&quot;pid&quot;:&quot;TR-937&quot;,&quot;id&quot;:48792132},
{&quot;name&quot;:&quot;MO001_MenteeA_PendingCounselor_200ok&quot;,&quot;qTestCaseId&quot;:25416626,&quot;pid&quot;:&quot;TR-938&quot;,&quot;id&quot;:48792133}]}</value>
         </entry>
      </properties>
      <type>TESTSUITE</type>
   </integratedEntity>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>0</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <testSuiteGuid>606f4a88-ecf2-4d40-a978-2e10112ff36f</testSuiteGuid>
   <testCaseLink>
      <guid>539494be-007b-40b3-ad06-27299938d149</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/SignUp/MO001_SignUpA_ValidStudent_200ok</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>2f2effb7-ae4e-4788-9fe3-114548a68942</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Mentors/MO014_MenteeA_AcceptedOther_201ok</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>12276a48-3aaa-4904-89b2-13019ba2f9eb</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Mentors/MO015_MenteeA_GetMentors_200ok</testCaseId>
   </testCaseLink>
</TestSuiteEntity>
