<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>Profile</name>
   <tag></tag>
   <integratedEntity>
      <productName>qTest</productName>
      <properties>
         <entry>
            <key>0</key>
            <value>{&quot;parent&quot;:{&quot;parentName&quot;:&quot;MO Sprint 8 20190509-20190530&quot;,&quot;name&quot;:&quot;Sprint 8 Katalon Automation API&quot;,&quot;id&quot;:1446467,&quot;type&quot;:4,&quot;parentId&quot;:354145},
&quot;default&quot;:true,&quot;name&quot;:&quot;Profile&quot;,&quot;pid&quot;:&quot;&quot;,&quot;id&quot;:2493650,&quot;testRuns&quot;:[{&quot;name&quot;:&quot;MO001_SignUpA_ValidStudent_200ok&quot;,&quot;qTestCaseId&quot;:25378536,&quot;pid&quot;:&quot;TR-935&quot;,&quot;id&quot;:48783104},
{&quot;name&quot;:&quot;MO001_UsersA_GetUserbyID_200ok&quot;,&quot;qTestCaseId&quot;:25389741,&quot;pid&quot;:&quot;TR-936&quot;,&quot;id&quot;:48783105}]}</value>
         </entry>
      </properties>
      <type>TESTSUITE</type>
   </integratedEntity>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>0</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <testSuiteGuid>92f33c6c-8665-47b1-9e0d-4fac6097cf74</testSuiteGuid>
   <testCaseLink>
      <guid>f9912560-4bc7-440e-a9ea-291abedd2689</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/SignUp/MO001_SignUpA_ValidStudent_200ok</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>9dff68f9-7e29-45ba-9856-2c22b2a92826</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Profile/MO001_UsersA_GetUserbyID_200ok</testCaseId>
   </testCaseLink>
</TestSuiteEntity>
