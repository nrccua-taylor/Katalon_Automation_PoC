<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>Test Scores</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>0</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <testSuiteGuid>9545697e-2b2f-42e7-ac5e-a0ce3dd7e442</testSuiteGuid>
   <testCaseLink>
      <guid>8b03ae5e-35ab-4b2e-ad4c-b292d8f37b84</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/SignUp/MO001_SignUpA_ValidStudent_200ok</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>bb565e33-e72d-43fa-b8c3-5bf9d7736176</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/TestScores/MO001_TestScoresA_GetTestScores_200ok</testCaseId>
   </testCaseLink>
</TestSuiteEntity>
