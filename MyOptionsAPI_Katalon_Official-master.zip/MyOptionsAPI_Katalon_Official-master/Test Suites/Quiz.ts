<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>Quiz</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>0</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <testSuiteGuid>64a6f81b-7cac-45f1-97b2-76dbb82dd8f7</testSuiteGuid>
   <testCaseLink>
      <guid>354fa9d1-b171-428b-b260-4bddf6af0ef8</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/SignUp/MO001_SignUpA_ValidStudent_200ok</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>697de937-f5e1-4de1-9a1d-d9869df6dff8</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Quiz/Answers/MO001_AnswersA_GetAnswers_200ok</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>422c9262-b9e7-4436-96d3-78985b548317</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Quiz/Answers/MO002_AnswersA_GetAnswerbyID_200ok-NOT READY YET (NEED TO SUPPLY ANSWERS)</testCaseId>
   </testCaseLink>
</TestSuiteEntity>
