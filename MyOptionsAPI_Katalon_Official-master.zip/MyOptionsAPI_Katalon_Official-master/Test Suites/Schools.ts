<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>Schools</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>0</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <testSuiteGuid>7a4e0387-e8f7-43ae-a571-c76b62c95d80</testSuiteGuid>
   <testCaseLink>
      <guid>9cafcf55-192a-4d5d-8aa0-3f848e8011e6</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/SignUp/MO001_SignUpA_ValidStudent_200ok</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>4286a25c-1f69-48c4-bebc-a247d51b1f81</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Schools/HighSchools/MO001_HighSchoolA_GetHighSchools_200ok</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>bd01e1c9-2d83-4b6e-a71d-ca438d60089a</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Schools/School_Details/MO001_SchoolsIDA_GetSchoolbyID_200ok</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>6bfa67d2-b168-4108-976e-6e800620da87</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Schools/User_Schools/MO001_UserSchoolsA_GetUserSchools_200ok</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>971f4ac5-22e2-42c6-86ea-1f823f4a70d5</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Schools/School_Details/MO002_SchoolA_CountSchools_200ok</testCaseId>
   </testCaseLink>
</TestSuiteEntity>
