<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>Press</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>0</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <testSuiteGuid>c5abd052-f118-4d70-b82c-8391dcfbb9d3</testSuiteGuid>
   <testCaseLink>
      <guid>39977880-a76b-475e-bf1e-7c010302be65</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/SignUp/MO001_SignUpA_ValidStudent_200ok</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>bb0d7281-ec61-4a03-bf21-82f778e79537</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Press/MO001_PressMentionA_GetPressMentions_200ok</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>7f5a6823-68d9-4cea-81f9-3d24b4260803</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Press/MO002_PressMentionA_GetPressMentionsbyID_200ok</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>0b9f804d-bcce-4469-93b4-6f5a7e4f211c</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Press/MO003_PressSourcesA_GetPressSources_200ok</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>d6417567-b55d-4aa1-9cc0-a148cf27aa7e</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Press/MO004_PressSourcesA_GetPressSourcesCount_200ok</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>58f46d9b-0c68-4d5e-9def-8dbda034c04a</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Press/MO005_PressSourcesA_GetPressSourcesbyID_200ok</testCaseId>
   </testCaseLink>
</TestSuiteEntity>
