<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>LoginSuite - Copy</name>
   <tag></tag>
   <integratedEntity>
      <productName>qTest</productName>
      <properties>
         <entry>
            <key>0</key>
            <value>{&quot;parent&quot;:{&quot;parentName&quot;:&quot;MO Sprint 3 20190124-20190213&quot;,&quot;name&quot;:&quot;Sprint 3 Testing-Dev&quot;,&quot;id&quot;:1361915,&quot;type&quot;:4,&quot;parentId&quot;:342024},
&quot;default&quot;:false,&quot;name&quot;:&quot;LoginSuite - Copy&quot;,&quot;pid&quot;:&quot;&quot;,&quot;id&quot;:0,&quot;testRuns&quot;:[]}</value>
         </entry>
      </properties>
      <type>TESTSUITE</type>
   </integratedEntity>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>0</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <testSuiteGuid>d0939277-cfb7-47a1-81b9-03557df11a90</testSuiteGuid>
   <testCaseLink>
      <guid>ca5d94f5-a958-44c0-98bb-b5e2af573e33</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Login/MO001_LoginA_ValidLogin_200ok</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>af7dd3f0-090d-4f82-a9f8-aa344d187d26</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Login/MO002_LoginA_InvalidPassword_401</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>dc6b957d-367b-4b06-a7b5-624feeb020c9</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Login/MO003_LoginA_InvalidUsername_401</testCaseId>
   </testCaseLink>
</TestSuiteEntity>
