<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>Regressionv2-Dev2</name>
   <tag></tag>
   <integratedEntity>
      <productName>qTest</productName>
      <properties>
         <entry>
            <key>0</key>
            <value>{&quot;parent&quot;:{&quot;parentName&quot;:&quot;MOM Sprint 3 20190530-20190619&quot;,&quot;name&quot;:&quot;Katalon API Automation Testing&quot;,&quot;id&quot;:1455405,&quot;type&quot;:4,&quot;parentId&quot;:358435},
&quot;default&quot;:false,&quot;name&quot;:&quot;Regressionv2-Dev2&quot;,&quot;pid&quot;:&quot;&quot;,&quot;id&quot;:2505063,&quot;testRuns&quot;:[]}</value>
         </entry>
         <entry>
            <key>1</key>
            <value>{&quot;parent&quot;:{&quot;parentName&quot;:&quot;MO Sprint 9 20190530-20190619&quot;,&quot;name&quot;:&quot;Katalon API Automation&quot;,&quot;id&quot;:1455413,&quot;type&quot;:4,&quot;parentId&quot;:358432},
&quot;default&quot;:true,&quot;name&quot;:&quot;Regressionv2-Dev2&quot;,&quot;pid&quot;:&quot;&quot;,&quot;id&quot;:2505069,&quot;testRuns&quot;:[{&quot;name&quot;:&quot;MO001_SignUpA_ValidStudent_200ok&quot;,&quot;qTestCaseId&quot;:25378536,&quot;pid&quot;:&quot;TR-999&quot;,&quot;id&quot;:49028373},
{&quot;name&quot;:&quot;MO001_LoginA_ValidLogin_200ok&quot;,&quot;qTestCaseId&quot;:25378558,&quot;pid&quot;:&quot;TR-1000&quot;,&quot;id&quot;:49028375},
{&quot;name&quot;:&quot;MO002_LoginA_InvalidPassword_401&quot;,&quot;qTestCaseId&quot;:25378559,&quot;pid&quot;:&quot;TR-1001&quot;,&quot;id&quot;:49028376},
{&quot;name&quot;:&quot;MO003_LoginA_InvalidUsername_401&quot;,&quot;qTestCaseId&quot;:25378560,&quot;pid&quot;:&quot;TR-1002&quot;,&quot;id&quot;:49028378},
{&quot;name&quot;:&quot;M0001_ChecklistA_GetChecklist_200ok&quot;,&quot;qTestCaseId&quot;:25378579,&quot;pid&quot;:&quot;TR-1003&quot;,&quot;id&quot;:49028381},
{&quot;name&quot;:&quot;M0002_ChecklistA_MarkTaskArchived_200ok&quot;,&quot;qTestCaseId&quot;:25378580,&quot;pid&quot;:&quot;TR-1004&quot;,&quot;id&quot;:49028398},
{&quot;name&quot;:&quot;MO003__ChecklistA_MarkTaskDone_200ok&quot;,&quot;qTestCaseId&quot;:25378581,&quot;pid&quot;:&quot;TR-1005&quot;,&quot;id&quot;:49028399},
{&quot;name&quot;:&quot;MO004_ChecklistA_MarkTaskToDo_200ok&quot;,&quot;qTestCaseId&quot;:25378582,&quot;pid&quot;:&quot;TR-1006&quot;,&quot;id&quot;:49028400},
{&quot;name&quot;:&quot;MO005_ChecklistA_DeleteTaskNotes_200ok&quot;,&quot;qTestCaseId&quot;:25378583,&quot;pid&quot;:&quot;TR-1007&quot;,&quot;id&quot;:49028402},
{&quot;name&quot;:&quot;MO006_ChecklistA_AddTaskNotes_200ok&quot;,&quot;qTestCaseId&quot;:25378584,&quot;pid&quot;:&quot;TR-1008&quot;,&quot;id&quot;:49028403},
{&quot;name&quot;:&quot;MO001_ArticlesA_GetAdvices_200ok&quot;,&quot;qTestCaseId&quot;:24447095,&quot;pid&quot;:&quot;TR-1009&quot;,&quot;id&quot;:49028405},
{&quot;name&quot;:&quot;MO002_ArticlesA_GetArticlesByIDslug_200ok&quot;,&quot;qTestCaseId&quot;:24447096,&quot;pid&quot;:&quot;TR-1010&quot;,&quot;id&quot;:49028406},
{&quot;name&quot;:&quot;MO003_ArticlesA_GetArticleAuthor_200ok&quot;,&quot;qTestCaseId&quot;:24447097,&quot;pid&quot;:&quot;TR-1011&quot;,&quot;id&quot;:49028407},
{&quot;name&quot;:&quot;MO001_UsersA_GetUserbyID_200ok&quot;,&quot;qTestCaseId&quot;:25389741,&quot;pid&quot;:&quot;TR-1012&quot;,&quot;id&quot;:49028408},
{&quot;name&quot;:&quot;TC1_SchoolAPI_GetUserSchools&quot;,&quot;qTestCaseId&quot;:24281189,&quot;pid&quot;:&quot;TR-1013&quot;,&quot;id&quot;:49028409},
{&quot;name&quot;:&quot;TC1_GetTestScores&quot;,&quot;qTestCaseId&quot;:24281188,&quot;pid&quot;:&quot;TR-1014&quot;,&quot;id&quot;:49028410},
{&quot;name&quot;:&quot;MO001_ResetPasswordA_ValidCredentials_200ok&quot;,&quot;qTestCaseId&quot;:25378691,&quot;pid&quot;:&quot;TR-1015&quot;,&quot;id&quot;:49028411},
{&quot;name&quot;:&quot;MO002_ResetPasswordA_InvalidFirstName_404&quot;,&quot;qTestCaseId&quot;:25378692,&quot;pid&quot;:&quot;TR-1016&quot;,&quot;id&quot;:49028412},
{&quot;name&quot;:&quot;MO003_ResetPasswordA_InvalidLastName_404&quot;,&quot;qTestCaseId&quot;:25378693,&quot;pid&quot;:&quot;TR-1017&quot;,&quot;id&quot;:49028414},
{&quot;name&quot;:&quot;MO004_ResetPasswordA_InvaidEmail_404&quot;,&quot;qTestCaseId&quot;:25378694,&quot;pid&quot;:&quot;TR-1018&quot;,&quot;id&quot;:49028415},
{&quot;name&quot;:&quot;MO005_ChangePasswordA_ValidCredentials_200ok&quot;,&quot;qTestCaseId&quot;:25378695,&quot;pid&quot;:&quot;TR-1019&quot;,&quot;id&quot;:49028416},
{&quot;name&quot;:&quot;MO006_ChangePasswordA_InvalidToken_500&quot;,&quot;qTestCaseId&quot;:25378696,&quot;pid&quot;:&quot;TR-1020&quot;,&quot;id&quot;:49028417},
{&quot;name&quot;:&quot;MO007_ChangePasswordA_BlankEmail_400&quot;,&quot;qTestCaseId&quot;:25378697,&quot;pid&quot;:&quot;TR-1021&quot;,&quot;id&quot;:49028418},
{&quot;name&quot;:&quot;MO008_ChangePasswordA_BlankFirstName_400&quot;,&quot;qTestCaseId&quot;:25378706,&quot;pid&quot;:&quot;TR-1022&quot;,&quot;id&quot;:49028419},
{&quot;name&quot;:&quot;MO009_ChangePasswordA_BlankLastName_400&quot;,&quot;qTestCaseId&quot;:25378707,&quot;pid&quot;:&quot;TR-1023&quot;,&quot;id&quot;:49028420},
{&quot;name&quot;:&quot;MO010_ChangePasswordA_BlankPassword_400&quot;,&quot;qTestCaseId&quot;:25378708,&quot;pid&quot;:&quot;TR-1024&quot;,&quot;id&quot;:49028421},
{&quot;name&quot;:&quot;MO011_VerifyEmailA_ValidCredentials_200ok&quot;,&quot;qTestCaseId&quot;:25378709,&quot;pid&quot;:&quot;TR-1025&quot;,&quot;id&quot;:49028422},
{&quot;name&quot;:&quot;MO012_VerifyEmailA_InvalidToken_500&quot;,&quot;qTestCaseId&quot;:25378710,&quot;pid&quot;:&quot;TR-1026&quot;,&quot;id&quot;:49028424},
{&quot;name&quot;:&quot;MO013_VerifyEmailA_BlankEmail_400&quot;,&quot;qTestCaseId&quot;:25378711,&quot;pid&quot;:&quot;TR-1027&quot;,&quot;id&quot;:49028425},
{&quot;name&quot;:&quot;MO014_VerfiyEmailA_BlankFirstName_400&quot;,&quot;qTestCaseId&quot;:25378712,&quot;pid&quot;:&quot;TR-1028&quot;,&quot;id&quot;:49028426},
{&quot;name&quot;:&quot;MO015_VerifyEmailA_BlankFirstName_400&quot;,&quot;qTestCaseId&quot;:25378713,&quot;pid&quot;:&quot;TR-1029&quot;,&quot;id&quot;:49028427},
{&quot;name&quot;:&quot;MO001_PressMentionA_GetPressMentions_200ok&quot;,&quot;qTestCaseId&quot;:25563597,&quot;pid&quot;:&quot;TR-1030&quot;,&quot;id&quot;:49028428},
{&quot;name&quot;:&quot;MO002_PressMentionA_GetPressMentionsbyID_200ok&quot;,&quot;qTestCaseId&quot;:25563598,&quot;pid&quot;:&quot;TR-1031&quot;,&quot;id&quot;:49028429},
{&quot;name&quot;:&quot;MO003_PressSourcesA_GetPressSources_200ok&quot;,&quot;qTestCaseId&quot;:25563599,&quot;pid&quot;:&quot;TR-1032&quot;,&quot;id&quot;:49028430},
{&quot;name&quot;:&quot;MO004_PressSourcesA_GetPressSourcesCount_200ok&quot;,&quot;qTestCaseId&quot;:25563600,&quot;pid&quot;:&quot;TR-1033&quot;,&quot;id&quot;:49028431},
{&quot;name&quot;:&quot;MO005_PressSourcesA_GetPressSourcesbyID_200ok&quot;,&quot;qTestCaseId&quot;:25563601,&quot;pid&quot;:&quot;TR-1034&quot;,&quot;id&quot;:49028432},
{&quot;name&quot;:&quot;MO002_SignUpA_InvalidStudentEmail_500&quot;,&quot;qTestCaseId&quot;:25624688,&quot;pid&quot;:&quot;TR-1048&quot;,&quot;id&quot;:49028589},
{&quot;name&quot;:&quot;MO003_SignUpA_BlankPassswordStudent_400&quot;,&quot;qTestCaseId&quot;:25624689,&quot;pid&quot;:&quot;TR-1049&quot;,&quot;id&quot;:49028598},
{&quot;name&quot;:&quot;MO004_SignUpA_BlankFirstNameStudent_400&quot;,&quot;qTestCaseId&quot;:25624690,&quot;pid&quot;:&quot;TR-1050&quot;,&quot;id&quot;:49028599},
{&quot;name&quot;:&quot;MO005_SignUpA_BlankLastNameStudent_400&quot;,&quot;qTestCaseId&quot;:25624691,&quot;pid&quot;:&quot;TR-1051&quot;,&quot;id&quot;:49028600},
{&quot;name&quot;:&quot;MO001_QuestionsA_GetQuestions_200ok&quot;,&quot;qTestCaseId&quot;:25624683,&quot;pid&quot;:&quot;TR-1052&quot;,&quot;id&quot;:49028601},
{&quot;name&quot;:&quot;MO002_QuestionsA_GetQuestionsCount_200ok&quot;,&quot;qTestCaseId&quot;:25624684,&quot;pid&quot;:&quot;TR-1053&quot;,&quot;id&quot;:49028602},
{&quot;name&quot;:&quot;MO003_QuestionsA_GetQuestionsbyID_200ok&quot;,&quot;qTestCaseId&quot;:25624685,&quot;pid&quot;:&quot;TR-1054&quot;,&quot;id&quot;:49028603},
{&quot;name&quot;:&quot;MO001_AnswersA_GetAnswers_200ok&quot;,&quot;qTestCaseId&quot;:25624681,&quot;pid&quot;:&quot;TR-1055&quot;,&quot;id&quot;:49028604},
{&quot;name&quot;:&quot;MO001_HighSchoolA_GetHighSchools_200ok&quot;,&quot;qTestCaseId&quot;:25624711,&quot;pid&quot;:&quot;TR-1056&quot;,&quot;id&quot;:49028605},
{&quot;name&quot;:&quot;MO001_SchoolsIDA_GetSchoolbyID_200ok&quot;,&quot;qTestCaseId&quot;:25624712,&quot;pid&quot;:&quot;TR-1057&quot;,&quot;id&quot;:49028606},
{&quot;name&quot;:&quot;MO002_SchoolA_CountSchools_200ok&quot;,&quot;qTestCaseId&quot;:25624713,&quot;pid&quot;:&quot;TR-1058&quot;,&quot;id&quot;:49028607},
{&quot;name&quot;:&quot;MO001_UserSchoolsA_GetUserSchools_200ok&quot;,&quot;qTestCaseId&quot;:25624718,&quot;pid&quot;:&quot;TR-1059&quot;,&quot;id&quot;:49028608},
{&quot;name&quot;:&quot;MO001_TestScoresA_GetTestScores_200ok&quot;,&quot;qTestCaseId&quot;:25624717,&quot;pid&quot;:&quot;TR-1060&quot;,&quot;id&quot;:49028609},
{&quot;name&quot;:&quot;MO001_MenteeA_PendingCounselor_200ok&quot;,&quot;qTestCaseId&quot;:25416626,&quot;pid&quot;:&quot;TR-1073&quot;,&quot;id&quot;:49371259},
{&quot;name&quot;:&quot;MO002_MenteeA_AcceptedCounselor_200ok&quot;,&quot;qTestCaseId&quot;:26009573,&quot;pid&quot;:&quot;TR-1074&quot;,&quot;id&quot;:49371260},
{&quot;name&quot;:&quot;MO003_MenteeA_PendingTeacher_201ok&quot;,&quot;qTestCaseId&quot;:26009574,&quot;pid&quot;:&quot;TR-1075&quot;,&quot;id&quot;:49371261},
{&quot;name&quot;:&quot;MO004_MenteeA_AcceptedTeacher_201ok&quot;,&quot;qTestCaseId&quot;:26009575,&quot;pid&quot;:&quot;TR-1076&quot;,&quot;id&quot;:49371262},
{&quot;name&quot;:&quot;MO005_MenteeA_PendingParent_201ok&quot;,&quot;qTestCaseId&quot;:26009576,&quot;pid&quot;:&quot;TR-1077&quot;,&quot;id&quot;:49371263},
{&quot;name&quot;:&quot;MO006_MenteeA_AcceptedParent_201ok&quot;,&quot;qTestCaseId&quot;:26009577,&quot;pid&quot;:&quot;TR-1078&quot;,&quot;id&quot;:49371264},
{&quot;name&quot;:&quot;MO007_MenteeA_PendingSibling_201ok&quot;,&quot;qTestCaseId&quot;:26009578,&quot;pid&quot;:&quot;TR-1079&quot;,&quot;id&quot;:49371265},
{&quot;name&quot;:&quot;MO008_MenteeA_AcceptedSibling_201ok&quot;,&quot;qTestCaseId&quot;:26009579,&quot;pid&quot;:&quot;TR-1080&quot;,&quot;id&quot;:49371266},
{&quot;name&quot;:&quot;MO009_MenteeA_PendingFamily_201ok&quot;,&quot;qTestCaseId&quot;:26009580,&quot;pid&quot;:&quot;TR-1081&quot;,&quot;id&quot;:49371267},
{&quot;name&quot;:&quot;MO010_MenteeA_AcceptedFamily_201ok&quot;,&quot;qTestCaseId&quot;:26009581,&quot;pid&quot;:&quot;TR-1082&quot;,&quot;id&quot;:49371268},
{&quot;name&quot;:&quot;MO011_MenteeA_PendingCoach_201ok&quot;,&quot;qTestCaseId&quot;:26009582,&quot;pid&quot;:&quot;TR-1083&quot;,&quot;id&quot;:49371269},
{&quot;name&quot;:&quot;MO012_MenteeA_AcceptedCoach_201ok&quot;,&quot;qTestCaseId&quot;:26009583,&quot;pid&quot;:&quot;TR-1084&quot;,&quot;id&quot;:49371270},
{&quot;name&quot;:&quot;MO013_MenteeA_PendingOther_201ok&quot;,&quot;qTestCaseId&quot;:26009584,&quot;pid&quot;:&quot;TR-1085&quot;,&quot;id&quot;:49371271},
{&quot;name&quot;:&quot;MO014_MenteeA_AcceptedOther_201ok&quot;,&quot;qTestCaseId&quot;:26009585,&quot;pid&quot;:&quot;TR-1086&quot;,&quot;id&quot;:49371272},
{&quot;name&quot;:&quot;MO015_MenteeA_GetMentors_200ok&quot;,&quot;qTestCaseId&quot;:26025689,&quot;pid&quot;:&quot;TR-1103&quot;,&quot;id&quot;:49372647}]}</value>
         </entry>
      </properties>
      <type>TESTSUITE</type>
   </integratedEntity>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>0</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <testSuiteGuid>823748df-6b8d-4769-b4bf-72f73b3e7447</testSuiteGuid>
   <testCaseLink>
      <guid>bfb25509-bac3-4195-8ca1-ff270f3b03c1</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/SignUp/MO002_SignUpA_InvalidStudentEmail_500</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>2be72a3e-d48e-477c-abd2-9a9a567d34e9</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/SignUp/MO003_SignUpA_BlankPassswordStudent_400</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>ee17c9bd-e73d-49e5-8ec5-b254ac7ca36e</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/SignUp/MO004_SignUpA_BlankFirstNameStudent_400</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>f57abcf2-4e22-405b-be66-ef3e65a5e65b</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/SignUp/MO005_SignUpA_BlankLastNameStudent_400</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>c37dd2ee-14d5-49a3-953e-9dc05716aa01</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/SignUp/MO001_SignUpA_ValidStudent_200ok</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>f0c677d1-7d03-47cd-9879-35200b3061c3</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Login/MO001_LoginA_ValidLogin_200ok</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>48b243f6-4007-4bb4-b4bb-c4ffcbceb33d</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Login/MO002_LoginA_InvalidPassword_401</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>7f731909-4ef2-4f37-8084-5f59bdd0aebc</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Login/MO003_LoginA_InvalidUsername_401</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>e2e3fbf8-1923-4b1f-94d1-c2f9a54d4b5b</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Checklist/M0001_ChecklistA_GetChecklist_200ok</testCaseId>
      <variableLink>
         <testDataLinkId></testDataLinkId>
         <type>DEFAULT</type>
         <value></value>
         <variableId>eba3c5fd-dbab-45e6-9d4e-61e0dd968fd2</variableId>
      </variableLink>
      <variableLink>
         <testDataLinkId></testDataLinkId>
         <type>DEFAULT</type>
         <value></value>
         <variableId>5e1f22bf-0b5d-4905-8deb-ea1ee605f9f5</variableId>
      </variableLink>
   </testCaseLink>
   <testCaseLink>
      <guid>e143f75b-82b2-425d-8db8-4d7eca964b9f</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Checklist/M0002_ChecklistA_MarkTaskArchived_200ok</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>e483814a-ca33-4f67-bb14-cb2a11c6b853</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Checklist/MO003__ChecklistA_MarkTaskDone_200ok</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>3a597d4e-0390-4dd5-af36-1c925c23bcb0</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Checklist/MO004_ChecklistA_MarkTaskToDo_200ok</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>4c1b02b5-5b5d-4825-a8eb-597b9edcb6e9</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Checklist/MO005_ChecklistA_DeleteTaskNotes_200ok</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>db400a7a-97ea-4686-bc0d-7a4762f8284d</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Checklist/MO006_ChecklistA_AddTaskNotes_200ok</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>5690595a-be9a-4a9c-83da-4bad63df9edb</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Articles/MO001_ArticlesA_GetAdvices_200ok</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>826aa716-970e-4340-b1cd-b71d5ce9fb1e</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Articles/MO002_ArticlesA_GetArticlesByIDslug_200ok</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>fad37541-26eb-44ed-9d13-64c23dc7f3ed</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Articles/MO003_ArticlesA_GetArticleAuthor_200ok</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>401308f3-ea2f-4f0e-b245-91ad8cea8308</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Profile/MO001_UsersA_GetUserbyID_200ok</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>ce59dcce-519f-4a29-b9f8-1f13a7cf31b1</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Quiz/MO001_QuestionsA_GetQuestions_200ok</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>b755d712-cca3-4645-b835-1123a465dc69</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Quiz/MO002_QuestionsA_GetQuestionsCount_200ok</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>6ae2f70f-2a5c-4d39-b7cb-dc529e6795e9</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Quiz/MO003_QuestionsA_GetQuestionsbyID_200ok</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>f331b11b-a8ca-4be0-938a-53dbd4a92422</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Quiz/Answers/MO001_AnswersA_GetAnswers_200ok</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>e5802749-9294-4ef3-a5c9-8ae48d9ade3a</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Schools/HighSchools/MO001_HighSchoolA_GetHighSchools_200ok</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>b7c37635-406f-4520-a13b-ba036cc24253</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Schools/School_Details/MO001_SchoolsIDA_GetSchoolbyID_200ok</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>afa19d90-7b99-4e9a-a9b7-08f4721c4e60</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Schools/School_Details/MO002_SchoolA_CountSchools_200ok</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>7312933f-e1cf-4f1b-9488-144a9f9dc769</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Schools/User_Schools/MO001_UserSchoolsA_GetUserSchools_200ok</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>8b271f78-34aa-40f6-b1b2-c2260e541adc</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/TestScores/MO001_TestScoresA_GetTestScores_200ok</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>7a389784-1549-421b-ab2c-fae9dd192195</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/UserMgmt/MO001_ResetPasswordA_ValidCredentials_200ok</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>a9528674-a66b-439b-b287-949d44316d25</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/UserMgmt/MO002_ResetPasswordA_InvalidFirstName_404</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>66e012e4-d60c-4b20-8899-f55bf333e951</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/UserMgmt/MO003_ResetPasswordA_InvalidLastName_404</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>dc9abd4e-f960-4e12-b1cc-d30505b06ce7</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/UserMgmt/MO004_ResetPasswordA_InvaidEmail_404</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>023b69ec-a0e9-4599-942a-5a5ab97876f8</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/UserMgmt/MO005_ChangePasswordA_ValidCredentials_200ok</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>fbf3ec31-cb2c-4c62-8904-9f4969eea40e</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/UserMgmt/MO006_ChangePasswordA_InvalidToken_500</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>a3f18968-457d-44c5-a747-87cdaafdc2a6</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/UserMgmt/MO007_ChangePasswordA_BlankEmail_400</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>c6b19cae-aa18-4b0d-a943-c17e6c999711</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/UserMgmt/MO008_ChangePasswordA_BlankFirstName_400</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>69fef712-93d1-45c3-981c-d6033463aac8</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/UserMgmt/MO009_ChangePasswordA_BlankLastName_400</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>2230de77-94a5-49d9-9b1a-d89b9125ba52</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/UserMgmt/MO010_ChangePasswordA_BlankPassword_400</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>550d7abd-16dc-4cba-b0cd-18177ec0d49f</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/UserMgmt/MO011_VerifyEmailA_ValidCredentials_200ok</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>c362c621-2f3f-4c1f-84a4-da3b8f4364ee</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/UserMgmt/MO012_VerifyEmailA_InvalidToken_500</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>64edd417-7df7-43a5-a537-6f9adca9ac6e</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/UserMgmt/MO013_VerifyEmailA_BlankEmail_400</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>1bd435fc-9256-46c0-89ac-39a96f815683</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/UserMgmt/MO014_VerfiyEmailA_BlankFirstName_400</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>77e51cb3-0b9f-4de8-a30b-b34ba686d8c2</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/UserMgmt/MO015_VerifyEmailA_BlankLastName_400</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>df65543d-68d8-4fe8-8489-3b637bac6961</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Press/MO001_PressMentionA_GetPressMentions_200ok</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>1e17da1c-50bd-4aa6-809b-0781b6cd4f68</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Press/MO002_PressMentionA_GetPressMentionsbyID_200ok</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>88f51a73-c735-47df-8059-bcf69cb6712d</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Press/MO003_PressSourcesA_GetPressSources_200ok</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>a84d8df8-a0ea-4f5a-b0dc-8c12cbcd90eb</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Press/MO004_PressSourcesA_GetPressSourcesCount_200ok</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>7c21b838-d064-471a-b6e8-50d7fa17d826</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Press/MO005_PressSourcesA_GetPressSourcesbyID_200ok</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>cc76a2f4-e5dd-412c-bf8f-f2ca4a882c48</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Mentors/MO001_MenteeA_PendingCounselor_200ok</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>d50e771b-2ea9-426f-8d26-3cb0731aafd0</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Mentors/MO002_MenteeA_AcceptedCounselor_200ok</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>40b962f2-dce0-4a3e-ba30-b492fdb2753f</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Mentors/MO003_MenteeA_PendingTeacher_201ok</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>0840716c-1739-4e0a-ae11-30e80ad775da</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Mentors/MO004_MenteeA_AcceptedTeacher_201ok</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>9246af37-fdf2-4095-8670-5bb550a57a0b</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Mentors/MO005_MenteeA_PendingParent_201ok</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>48d6aa4d-8fd4-4e0f-8b79-c603cb236bc5</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Mentors/MO006_MenteeA_AcceptedParent_201ok</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>51fb3ad6-7828-4ef9-bf24-3c1a652c98ef</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Mentors/MO007_MenteeA_PendingSibling_201ok</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>31af4ff0-1092-4337-9b87-2c522fb810f0</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Mentors/MO008_MenteeA_AcceptedSibling_201ok</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>fda44197-1a4a-49a9-a919-049238a7cc6d</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Mentors/MO009_MenteeA_PendingFamily_201ok</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>93c54fdb-6aa8-4bb7-a0b3-1f54bdbb4cea</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Mentors/MO010_MenteeA_AcceptedFamily_201ok</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>2be4fb88-fe55-4f3d-b81f-c4865afcd4bc</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Mentors/MO011_MenteeA_PendingCoach_201ok</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>a376a61f-0843-4385-9dd9-2e4c09f2680c</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Mentors/MO012_MenteeA_AcceptedCoach_201ok</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>44bcb44a-7b55-4d3f-afa9-286781069ca6</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Mentors/MO013_MenteeA_PendingOther_201ok</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>b3c8aa95-4839-4dfb-9e04-745c849b86fd</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Mentors/MO014_MenteeA_AcceptedOther_201ok</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>dd6a80d7-c8a6-42c2-bec8-21427c4accb4</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Mentors/MO015_MenteeA_GetMentors_200ok</testCaseId>
   </testCaseLink>
</TestSuiteEntity>
